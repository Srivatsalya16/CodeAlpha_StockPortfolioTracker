prices={"AAPL":180,"TSLA":250,"GOOGLE":150}
stock=input("Enter stock name: ").upper()
qty=int(input("Enter quantity: "))
if stock in prices:
    total=prices[stock]*qty
    print("Total Investment =",total)
    with open("investment.txt","w") as f:
        f.write(f"Stock: {stock}\nQuantity: {qty}\nTotal Investment: {total}")
else:
    print("Stock not available.")
