import random
words=["apple","python","banana","laptop","orange"]
word=random.choice(words)
guessed=[]
tries=6
while tries>0:
    display=" ".join([c if c in guessed else "_" for c in word])
    print(display)
    if "_" not in display:
        print("Congratulations! You won.")
        break
    guess=input("Guess a letter: ").lower()
    if guess in guessed:
        print("Already guessed."); continue
    guessed.append(guess)
    if guess not in word:
        tries-=1
        print("Wrong guess! Remaining chances:",tries)
if tries==0:
    print("Game Over! Word was:",word)
